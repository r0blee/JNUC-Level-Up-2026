echo "What is your name?"
read name

if [[ $name == "John" ]]; then
    echo "You are John Lennon"
elif [[ $name == "Paul" ]]; then
    echo "You are Paul McCartney"
elif [[ $name == "George" ]]; then
    echo "You are George Harrison"
elif [[ $name == "Ringo" ]]; then
    echo "You are Ringo Starr"
else
    echo "You are not one of the Beatles"
fi