#!/bin/zsh --no-rcs

echo "What is your favorite browser: Safari, Firefox, or Chrome?"
read name

safariPath="/Applications/Safari.app"
firefoxPath="/Applications/Firefox.app"
chromePath="/Applications/Google Chrome.app"

if [[ $name == "Safari" || $name == "safari" && -e "$safariPath" ]]; then
	open "$safariPath"
elif [[ $name == "Firefox" && -e "$firefoxPath" ]]; then
	open "$firefoxPath"
elif [[ $name == "Chrome" && -e "$chromePath" ]]; then
	open "$chromePath"
else
	echo "That browser is not installed on this Mac"
fi

if [[ $name == "Firefox" || $name == "Chrome" ]]; then
	echo "Tip: consider syncing your bookmarks across devices"
fi