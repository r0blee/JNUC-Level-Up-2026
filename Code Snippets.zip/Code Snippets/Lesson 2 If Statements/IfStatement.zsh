#!/bin/zsh --no-rcs
echo "what is your name?"
read name

if [[ $name == John ]]; then
	echo "You are one of the Beatles"
elif
	[[ $name == Paul ]]; then
	echo "You are one of the Beatles"
fi