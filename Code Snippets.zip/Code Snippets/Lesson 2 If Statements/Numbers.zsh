#!/bin/zsh --no-rcs

num=10
if [[ $num -gt 10 ]]; then
	echo "Number is equal to 10"
else
	echo "Number does not equal to 10"
fi