#!/bin/zsh --no-rcs

echo "What is the weather? (rainy, cloudy, sunny, partly cloudy, or something else)"
read weather

if [[ "$weather" == "cloudy" || "$weather" == "rainy" ]]; then
	echo "Yes, you should take an umbrella"
elif [[ "$weather" == "sunny" || "$weather" == "partly cloudy" ]]; then
	echo "No, you do not need an umbrella today"
else
	echo "Check with the weather show"
fi