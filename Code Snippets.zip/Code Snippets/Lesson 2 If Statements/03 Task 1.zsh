#!/bin/zsh --no-rcs
# Determine the letter grade of a variable called "score" that follows the rules:
# Output using osascript "A" if the student scores 90 or above.
# Output using osascript "B" if the student scores 80 or above but less than 90.
# Output using osascript "C" if the student scores below 80.

echo "What is the score?"
read score

# Task 1a
# Output "A" if the student scores 90 or above.
if [[ ${score} -ge 90 ]]; then
	echo "That is an A"
fi

# Task 1b
# Output "B" if the student scores 80 or above but less than 90.
if [[ ${score} -ge 80 && ${score} -lt 90 ]]; then
	echo "That is a B"
fi

# Task 1c
# Output "C" if the student scores below 80.
if [[ ${score} -lt 80 ]]; then
	echo "That is a C"
fi