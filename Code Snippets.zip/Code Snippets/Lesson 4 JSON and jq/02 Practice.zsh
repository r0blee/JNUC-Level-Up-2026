#!/bin/zsh --no-rcs

file='/Users/jamfadmin/Final Materials/Code Snippets/Lesson 4 JSON and jq/01 sample_json.json'
#jq . $file

# Pull one value out of a flat object

#jq '.name' $file

# Pull a value out of a nested object with dot notation

#jq '.general.mdmCapable.capable' $file

# Grab one item out of an array by index.

#jq '.applications[0].version' $file

# Loop through an array and grab one key from every item

#jq '.applications[].name' $file

# Strip the surrounding quotes with --raw-output

#jq -r '.name' $file

# Strip color with --monochrome-output

#jq -M -r '.name' $file

# Save a jq result into a variable

#categoryName=$(jq --monochrome-output --raw-output '.name' $file)
#echo "$categoryName"

# JSON can also be piped into jq instead of read from a file. 

cat $file | jq -r -M '.name'
