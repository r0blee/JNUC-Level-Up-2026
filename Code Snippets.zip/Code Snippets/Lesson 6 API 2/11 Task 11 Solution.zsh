#!/bin/zsh --no-rcs

# Variables

client_id="68064099-b24d-4654-8dfe-b490a8df268d"
client_secret="vOwoE4R0QuHBmDAObCnLb6fiY63BbjNF"
envId="bdd98e91-21d3-4da3-8162-fe1594d6c97d"

# Get access token and save it as a variable

accessToken=$(curl --silent --request POST \
--url https://us.api.jamfcloud.com/auth/token \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'grant_type=client_credentials' \
--data-urlencode "client_id=$client_id" \
--data-urlencode "client_secret=$client_secret" | jq '.access_token' --raw-output)

# echo $accessToken

echo " (Optional) Task 11 Deploy - Undeploy a Blueprint - - - - - - -"

echo "Blueprint toggle utility - - - - - - -"

blueprintsJSON=$(curl --silent --request GET \
--url "https://us.api.jamfcloud.com/blueprints/v1/blueprints?page=0&page-size=100&sort=created%3Adesc" \
--header "accept: application/json" \
--header "X-Environment-Id: $envId" \
--header "authorization: Bearer $accessToken")

blueprintCount=$(echo "$blueprintsJSON" | jq '.results | length')

if [[ "$blueprintCount" -eq 0 ]]; then
	echo "No blueprints found."
else
	echo ""
	echo "  #   STATE          NAME"
	echo "  --  -----          ----"
	#	for ((i = 0; i < blueprintCount; i++)); do
	for ((i = 1; i <= blueprintCount; i++)); do
		idx=$((i - 1))
		name=$(echo "$blueprintsJSON" | jq --raw-output ".results[$idx].name")
		state=$(echo "$blueprintsJSON" | jq --raw-output ".results[$idx].deploymentState.state")
		printf "  %-3s %-14s %s\n" "$i" "$state" "$name"
	done
	echo ""
	
	read "selection?Enter the # of the blueprint to toggle, or q to quit: "
	
	if [[ "$selection" == "q" || -z "$selection" ]]; then
		echo "No action taken."
	else
		idx=$((selection - 1))
		toggleBlueprintID=$(echo "$blueprintsJSON" | jq --raw-output ".results[$idx].id")
		toggleBlueprintName=$(echo "$blueprintsJSON" | jq --raw-output ".results[$idx].name")
		toggleBlueprintState=$(echo "$blueprintsJSON" | jq --raw-output ".results[$idx].deploymentState.state")
		
		if [[ "$toggleBlueprintID" == "null" || -z "$toggleBlueprintID" ]]; then
			echo "Invalid selection."
		else
			if [[ "$toggleBlueprintState" == "DEPLOYED" || "$toggleBlueprintState" == "OUT_OF_DATE" ]]; then
				toggleAction="undeploy"
			elif [[ "$toggleBlueprintState" == "NOT_DEPLOYED" ]]; then
				toggleAction="deploy"
			else
				echo "Unrecognized state '$toggleBlueprintState' for '$toggleBlueprintName' - aborting."
				toggleAction=""
			fi
			
			if [[ -n "$toggleAction" ]]; then
				read "confirm?Blueprint '$toggleBlueprintName' is currently $toggleBlueprintState. Run $toggleAction on it? (y/n): "
				if [[ "$confirm" == "y" ]]; then
					curl --silent --request POST \
					--url "https://us.api.jamfcloud.com/blueprints/v1/blueprints/$toggleBlueprintID/$toggleAction" \
					--header "accept: application/json" \
					--header "X-Environment-Id: $envId" \
					--header "authorization: Bearer $accessToken"
					
					echo ""
					echo "$toggleAction requested for '$toggleBlueprintName'. This runs asynchronously - check its state again shortly to confirm it finished."
				else
					echo "Cancelled."
				fi
			fi
		fi
	fi
fi

