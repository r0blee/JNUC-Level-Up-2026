#!/bin/zsh --no-rcs

# Variables

client_id="68064099-b24d-4654-8dfe-b490a8df268d"
client_secret="vOwoE4R0QuHBmDAObCnLb6fiY63BbjNF"
envId="bdd98e91-21d3-4da3-8162-fe1594d6c97d"
blueprintID="ID"

# Get access token and save it as a variable

accessToken=$(curl --silent --request POST \
--url https://us.api.jamfcloud.com/auth/token \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'grant_type=client_credentials' \
--data-urlencode "client_id=$client_id" \
--data-urlencode "client_secret=$client_secret" | jq '.access_token' --raw-output)

succeededCount=$(curl --silent --request GET \
--url "https://us.api.jamfcloud.com/blueprints/v1/blueprints/$blueprintID/report" \
--header "accept: application/json" \
--header "X-Environment-Id: $environmentID" \
--header "authorization: Bearer $accessToken" | jq --monochrome-output --raw-output '.succeeded')

failedCount=$(curl --silent --request GET \
--url "https://us.api.jamfcloud.com/blueprints/v1/blueprints/$blueprintID/report" \
--header "accept: application/json" \
--header "X-Environment-Id: $environmentID" \
--header "authorization: Bearer $accessToken" | jq --monochrome-output --raw-output '.failed')

echo "Blueprint $blueprintID -> Succeeded: $succeededCount, Failed: $failedCount"