#!/bin/zsh --no-rcs

# Variables

client_id="68064099-b24d-4654-8dfe-b490a8df268d"
client_secret="vOwoE4R0QuHBmDAObCnLb6fiY63BbjNF"
envId="bdd98e91-21d3-4da3-8162-fe1594d6c97d"

# Get access token and save it as a variable
accessToken=$(curl --silent --request POST \
--url https://us.api.jamfcloud.com/auth/token \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'grant_type=client_credentials' \
--data-urlencode "client_id=$client_id" \
--data-urlencode "client_secret=$client_secret" | jq '.access_token' --raw-output)


# Get blueprint IDs
blueprints=$(curl --silent --request GET \
--url "https://us.api.jamfcloud.com/blueprints/v1/blueprints" \
--header 'accept: application/json' \
--header "Authorization: Bearer $accessToken" \
--header "X-Environment-Id: $envId")

# Ask the user which blueprint they want
echo "What blueprint do you want an ID for?"
read blueprintName

# Look up the ID matching that name
blueprintId=$(echo "$blueprints" | jq -r --arg name "$blueprintName" '.results[] | select(.name == $name) | .id')
	
	if [ -n "$blueprintId" ]; then
		echo "Blueprint ID: $blueprintId"
	else
		echo "No blueprint found named '$blueprintName'"
	fi