#!/bin/zsh --no-rcs

# Pre-check for a macOS upgrade that requires 15 GB of free space.

requiredSpace=15
comfortableSpace=25
upgradeTrigger="startUpgrade"

# Free space in whole GB on the data volume.
# df -g reports 1 GB blocks; field 4 of the second line is Available.
freeSpace=$(df -g /System/Volumes/Data | awk 'NR==2 {print $4}')

echo "Free space on the data volume: ${freeSpace} GB"

if (( freeSpace >= comfortableSpace )); then

	# Plenty of room. Heads up display, no decision to make.
	echo "Your Mac has ${freeSpace} GB free and is ready to upgrade."
	exit 0

elif (( freeSpace >= requiredSpace )); then

	# Enough to install, but tight. Let the user choose.
	needed=$(( comfortableSpace - freeSpace ))
	
	echo "This upgrade needs ${requiredSpace} GB free. Your Mac has ${freeSpace} GB. Free up ${needed} GB more for a comfortable install, or install anyway. Enter Yes to install now or No to defer." ; read userChoice

	if [[ $userChoice == "Yes" ]]; then
		echo "User chose to install anyway."
		sudo jamf policy -event "$upgradeTrigger"
	else
		echo "User deferred the upgrade."
	fi

	exit 0

else

	# Below the requirement. No deferral offered.
	echo "The upgrade is blocked. Your Mac has ${freeSpace} GB free and needs at least ${requiredSpace} GB. Contact the help desk."
	exit 1
fi