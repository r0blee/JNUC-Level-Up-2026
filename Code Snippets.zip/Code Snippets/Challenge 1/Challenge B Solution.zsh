#!/bin/zsh --no-rcs

# Guess the Number
# The script picks a secret number between 1 and 100. The user gets seven
# guesses, with a high or low hint after each miss. A blank entry does not
# consume a guess.

secret=$(( RANDOM % 100 + 1 ))
guesses=0
maxGuesses=7
found="no"

until [[ "$found" == "yes" || $guesses -ge $maxGuesses ]]; do
	((guesses++))

	# Build the question first, then ask it
	echo "Guess the number between 1 and 100. Guess $guesses of $maxGuesses."; read guess
	if [[ -z "$guess" ]]; then
		echo "Enter a number."
		((guesses--))
	elif (( guess > secret )); then
		echo "Too high."
	elif (( guess < secret )); then
		echo "Too low."
	else
		found="yes"
	fi
done

if [[ "$found" == "yes" ]]; then
	echo "Correct. The number was $secret, found in $guesses guesses."
else
	echo "Out of guesses. The number was $secret."
fi
