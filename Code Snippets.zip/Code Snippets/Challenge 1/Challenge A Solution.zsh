#!/bin/zsh --no-rcs
score=0

# Loop 5 times
for i in {1..5}; do
	# Generate two random numbers between 1 and 10
	num1=$(( RANDOM % 10 + 1 ))
	num2=$(( RANDOM % 10 + 1 ))
	
	# Calculate the correct answer
	correct=$(( num1 + num2 ))
	echo -n "What is $num1 + $num2? "
	read answer
	
	# Check if the answer is correct
	if [ "$answer" -eq "$correct" ]; then
		echo "Correct!"
		((score++))
	else
		echo "Wrong!!"
	fi
done

# Final score
echo "Final Score: $score"