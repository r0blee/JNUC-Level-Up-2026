#!/bin/zsh --no-rcs

# Continuously prompt a user with echo until they enter the secret word JNUC.

until [[ ${secret} == "JNUC" ]]
do
    echo "Enter the secret word."
    read secret 
done
echo "Great job!"