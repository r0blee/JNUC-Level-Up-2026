#!/bin/zsh --no-rcs


filename="/Users/jamfadmin/Desktop/file.txt"

until [[ -f "$filename" ]];do
	echo "File does not exist"
	sleep 2
	
	if [[ -f "$filename" ]]; then
		echo "you've got it"
		exit 0
	fi
done