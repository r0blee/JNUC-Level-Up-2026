#!/bin/zsh --no-rcs

# Given a list of scores below, iterate through each list if their is a invalid number (Below 0 or above 100). Print out the student score along with "invalid score"
# (-56, 72, 84, 99)
# (0, 100, 55, 56)

# Task 3a
# (-56, 72, 84, 99)
for score in -56 72 84 99
do
	echo -n "${score}"
	if [[ "${score}" -lt 0 ]] || [[ "${score}" -gt 100 ]]
	then
		echo ": Invalid score"
	else
		echo ""
	fi
	sleep 1
done

## Task 3b
## (0, 100, 55, 56)
#for score in 0 100 55 56
#do
#	echo -n "${score}"
#	if [[ "${score}" -lt 0 ]] || [[ "${score}" -gt 100 ]]
#	then
#		echo ": Invalid score"
#	else
#		echo ""
#	fi
#done