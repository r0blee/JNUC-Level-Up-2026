#!/bin/zsh --no-rcs

# Given a list of scores below, iterate through each list and if the student scores 60 or above, print out what student has scored, if they score below print the student has failed.
# a. (59, 58, 61, 63, 99)
# b. (60, 72, 37, 38, 40)

# Task 1a
#for score in 59 58 61 63 99
#do
#	if [[ "${score}" -lt 60 ]]
#	then
#		echo "Failed"
#	else
#		echo "${score}"
#	fi
#done

# Task 1b
for score in 60 72 37 38 40
do
	if [[ "${score}" -lt 60 ]]
	then
		echo "Failed"
	else
		echo "${score}"
	fi
	sleep 1
done

