#!/bin/zsh --no-rcs
jnuc=2026

for color in red blue green grey black;
do
	echo $color
	sleep 1
done
