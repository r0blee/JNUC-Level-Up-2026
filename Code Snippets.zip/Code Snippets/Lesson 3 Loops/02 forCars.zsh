#!/bin/zsh --no-rcs

dir='/Users/jamfadmin/Final Materials/cars'

#for item in "$dir"/*; do
#	if [[ -d "$item" ]]; then
#		echo "$item"
#		sleep 1
#	fi
#done

for item in "$dir"/*; do
	if [[ -d "$item" ]]; then
		((count++))
	fi
done
echo $count
