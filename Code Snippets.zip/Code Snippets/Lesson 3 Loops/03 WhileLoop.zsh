#!/bin/zsh --no-rcs

answer="yes"

while [[ $answer == "Yes" || $answer == "yes" ]];do
	echo "Enter the secret code"
	read code

	if [[ $code == "Level Up" ]]; then
		echo "You Guessed the code!"
		exit 0
	fi
	
done 