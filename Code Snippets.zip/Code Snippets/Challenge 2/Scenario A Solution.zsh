#!/bin/zsh --no-rcs

client_id="CLIENT ID HERE"
client_secret="CLIENT SECRET HERE"
environmentID="ENVIRONMENT ID HERE"

accessToken=$(curl --silent --request POST \
	--url "https://us.api.jamfcloud.com/auth/token" \
	--header 'Content-Type: application/x-www-form-urlencoded' \
	--data-urlencode 'grant_type=client_credentials' \
	--data-urlencode "client_id=$client_id" \
	--data-urlencode "client_secret=$client_secret" \
	| jq --raw-output '.access_token')

echo "$accessToken"

blueprintIDs=($(curl --silent --request GET \
--url "https://us.api.jamfcloud.com/blueprints/v1/blueprints" \
--header "accept: application/json" \
--header "X-Environment-Id: $environmentID" \
--header "authorization: Bearer $accessToken" | jq --monochrome-output --raw-output '.results[].id'))

for blueprintID in "${blueprintIDs[@]}"; do
	succeededCount=$(curl --silent --request GET \
		--url "https://us.api.jamfcloud.com/blueprints/v1/blueprints/$blueprintID/report" \
		--header "accept: application/json" \
		--header "X-Environment-Id: $environmentID" \
		--header "authorization: Bearer $accessToken" | jq --monochrome-output --raw-output '.succeeded')
	
	failedCount=$(curl --silent --request GET \
		--url "https://us.api.jamfcloud.com/blueprints/v1/blueprints/$blueprintID/report" \
		--header "accept: application/json" \
		--header "X-Environment-Id: $environmentID" \
		--header "authorization: Bearer $accessToken" | jq --monochrome-output --raw-output '.failed')
	
	echo "Blueprint $blueprintID -> Succeeded: $succeededCount, Failed: $failedCount"
	if [[ "$failedCount" == 0 ]];then
		echo "Healthy"
	elif [[ "$failedCount" != "0" && "$failedCount" -lt "$succeededCount" ]];then
		echo "Needs attention"
	else
		echo "Critical"
	fi
done
