#!/bin/zsh --no-rcs

client_id="CLIENT ID HERE"
client_secret="CLIENT SECRET HERE"
environmentID="ENVIRONMENT ID HERE"

accessToken=$(curl --silent --request POST \
	--url "https://us.api.jamfcloud.com/auth/token" \
	--header 'Content-Type: application/x-www-form-urlencoded' \
	--data-urlencode 'grant_type=client_credentials' \
	--data-urlencode "client_id=$client_id" \
	--data-urlencode "client_secret=$client_secret" \
	| jq --raw-output '.access_token')

echo "$accessToken"

read "managementID?Enter a Management ID: "

capable=$(curl --silent --request GET \
	--url "https://us.api.jamfcloud.com/devices/v1/devices/$managementID" \
	--header "accept: application/json" \
	--header "X-Environment-Id: $environmentID" \
	--header "authorization: Bearer $accessToken" | jq --monochrome-output --raw-output '.mdmCapable')

serialNumber=$(curl --silent --request GET \
	--url "https://us.api.jamfcloud.com/devices/v1/devices/$managementID" \
	--header "accept: application/json" \
	--header "X-Environment-Id: $environmentID" \
	--header "authorization: Bearer $accessToken" | jq --monochrome-output --raw-output '.hardware.serialNumber')

if [[ "$capable" == "true" ]];then
	echo "Device $serialNumber is compliant"
else
	echo "Device $serialNumber is out of compliance, contact the help desk"
fi