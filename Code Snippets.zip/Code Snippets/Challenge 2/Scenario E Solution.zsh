#!/bin/zsh --no-rcs
# The sample arrays below deliberately mix IDs that exist in the training tenant with IDs that do not (200 and 500 for departments, 203 and 501 for categories), so groups see both branches of the if statement fire

client_id="CLIENT ID HERE"
client_secret="CLIENT SECRET HERE"
environmentID="ENVIRONMENT ID HERE"

accessToken=$(curl --silent --request POST \
	--url "https://us.api.jamfcloud.com/auth/token" \
	--header 'Content-Type: application/x-www-form-urlencoded' \
	--data-urlencode 'grant_type=client_credentials' \
	--data-urlencode "client_id=$client_id" \
	--data-urlencode "client_secret=$client_secret" \
	| jq --raw-output '.access_token')

echo "$accessToken"

departmentIDs=("200" "1" "2" "3" "4" "500")
categoryIDs=("203" "1" "2" "3" "4" "501")

for department in ${departmentIDs[@]};do
	departmentName=$(curl --silent --request GET \
	--url "https://us.api.jamfcloud.com/pro/v1/departments/$department" \
	--header "accept: application/json" \
	--header "X-Environment-Id: $environmentID" \
	--header "authorization: Bearer $accessToken" | jq --raw-output '.name')
	if [[ $departmentName == "null" ]];then
		echo "Department id $department does not exist"
	else
		echo "Department found: $departmentName"
	fi
done

for category in ${categoryIDs[@]};do
	categoryName=$(curl --silent --request GET \
	--url "https://us.api.jamfcloud.com/pro/v1/categories/$category" \
	--header "accept: application/json" \
	--header "X-Environment-Id: $environmentID" \
	--header "authorization: Bearer $accessToken" | jq --raw-output '.name')
	if [[ $categoryName == "null" ]];then
		echo "Category id $category does not exist"
	else
		echo "Category found: $categoryName"
	fi
done