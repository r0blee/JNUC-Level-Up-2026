#!/bin/zsh --no-rcs

client_id="CLIENT ID HERE"
client_secret="CLIENT SECRET HERE"
environmentID="ENVIRONMENT ID HERE"

accessToken=$(curl --silent --request POST \
	--url "https://us.api.jamfcloud.com/auth/token" \
	--header 'Content-Type: application/x-www-form-urlencoded' \
	--data-urlencode 'grant_type=client_credentials' \
	--data-urlencode "client_id=$client_id" \
	--data-urlencode "client_secret=$client_secret" \
	| jq --raw-output '.access_token')

echo "$accessToken"

read "targetBuilding?Enter a building name to look up: "

buildingIDs=($(curl --silent --request GET \
--url "https://us.api.jamfcloud.com/pro/v1/buildings" \
--header "accept: application/json" \
--header "X-Environment-Id: $environmentID" \
--header "authorization: Bearer $accessToken" | jq --monochrome-output --raw-output '.results[].id'))

count=0
for id in ${buildingIDs[@]};do
	buildingName=$(curl --silent --request GET \
	--url "https://us.api.jamfcloud.com/pro/v1/buildings/$id" \
	--header "accept: application/json" \
	--header "X-Environment-Id: $environmentID" \
	--header "authorization: Bearer $accessToken" | jq --monochrome-output --raw-output '.name')
	((count++))
	if [[ $targetBuilding == "$buildingName" ]];then
		echo "Found building: $buildingName"
	else
		echo "Building not found: comparing $targetBuilding with $buildingName"
	fi
done
echo "Total buildings: $count"